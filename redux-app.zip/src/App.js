import './App.css';
import Header from './component/Header';
import WatchProduct from './component/WatchProduct';

function App() {
  return (
    <div className="App">
      {/* hello */}
      <Header/>
      <WatchProduct/>
   
    </div>
  );
}

export default App;
