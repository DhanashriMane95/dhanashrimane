import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import WatchAction from '../redux/WatchAction'

const WatchProduct = () => {
    const count= useSelector(state=>state.numOfCartProduct)
    const dispatch = useDispatch();

  return (

        <>
            <div>
                <h3>Cart :{count}</h3>
                <button onClick={()=>dispatch(WatchAction())}>Add to Cart</button>
            </div>
        </>
  )
}

export default WatchProduct