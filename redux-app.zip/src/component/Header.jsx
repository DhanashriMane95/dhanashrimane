import React from 'react'
import { useSelector } from 'react-redux'
const Header = () => {
    const count = useSelector(state=>state.numOfCartProduct)
    return (
        <>
            <div style={{border:"1px solid black", padding:"10px" }}>
                <h1>Cart:{count}</h1>
            </div>
        </>
    )
}

export default Header