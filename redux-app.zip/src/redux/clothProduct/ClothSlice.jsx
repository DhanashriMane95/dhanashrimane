import {createSlice} from '@reduxjs/toolkit'

const initialState={
    clothCount:0
}

const ClothSlice = createSlice({
    name:'Cloth',
    initialState,
    reducers:{
      BUY_CLOTH_PRODUCT: (state)=>{
        return{
            ...state,
            clothCount: state.clothCount-1
        }
      },
      ADD_CLOTH_PRODUCT:(state)=>{
        return{
            ...state,
            clothCount: state.clothCount+1
        }
      },
      RESET_CLOTH_PRODUCT: (state)=>{
        return{
            ...initialState
        }
      }
    }
})

export const {BUY_CLOTH_PRODUCT, ADD_CLOTH_PRODUCT, RESET_CLOTH_PRODUCT} = ClothSlice.actions;
export default ClothSlice.reducer
