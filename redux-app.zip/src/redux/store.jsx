import {applyMiddleware, createStore} from 'redux'
import {WatchReducer} from './WatchReducer'
import {composeWithDevTools} from 'redux-devtools-extension';
import logger from 'redux-logger'

export const store=createStore(WatchReducer, composeWithDevTools(applyMiddleware(logger)))

