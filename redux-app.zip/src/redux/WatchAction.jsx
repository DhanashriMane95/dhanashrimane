import React from 'react'
import { ADD_TO_CART } from './WatchConstant'

const WatchAction = () => {
  return{
    type: ADD_TO_CART
 }
}

export default WatchAction