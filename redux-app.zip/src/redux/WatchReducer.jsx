import { ADD_TO_CART } from './WatchConstant'

const initialState={
    numOfCartProduct: 0,
}
export const WatchReducer = (state=initialState, action) => {
    switch(action.type){
        case ADD_TO_CART:
            return{
                ...state,
                numOfCartProduct: state.numOfCartProduct+1
            }
        default : return state ;
    }
}
