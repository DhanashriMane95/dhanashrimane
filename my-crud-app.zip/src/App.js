import './assets/style.css'
// import './App.css';
import Crud from './components/Crud';
function App() {
  return (
    <div className="App">
       <h1 className='text-center fw-bold'>
       <i style={{ color: "#12129f", background: "aliceblue"}}> Crud Application</i>
       </h1>
       <Crud/>
    </div>
  );
}

export default App;
