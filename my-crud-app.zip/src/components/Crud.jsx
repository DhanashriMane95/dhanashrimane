import React, { useEffect, useState } from 'react'
import axios from 'axios'
const Crud = () => {
  const initialVal = {
    fname: '',
    lname: '',
    email: '',
    mobile: '',
    address: '',
  }
  const [UserData, setUserData] = useState([]);
  const [PostUser, setPostUser] = useState(initialVal);
  const[id, setId]=useState();
  useEffect(() => {
    getUserData();
  }, []);

  // get data from json
  const getUserData = () => {
    axios.get(`http://localhost:3001/users`)
      .then((res) => setUserData(res.data)).catch((error) => { console.warn(error) })
  }

  const formStateChange = (e, field) => {
    let newStateData = { ...PostUser };
    switch (field) {
      // text
      case "FNAME":
        newStateData.fname = e.target.value
        break;
      case "LNAME":
        newStateData.lname = e.target.value
        break;
      case "EMAIL":
        newStateData.email = e.target.value
        break;
      case "MOBILE":
        newStateData.mobile = e.target.value
        break;
      case "ADDRESS":
        newStateData.address = e.target.value
        break;
        default:
          break;
      }
      setPostUser({ ...newStateData });
  }

//post data to json
    const postUserData=()=>{
      axios.post(`http://localhost:3001/users`, PostUser)
      .then((response)=>{
        // console.log(response.data);
        setPostUser(initialVal);
        getUserData();
      })
    }

//put or edit data in json
  const editUserData=(id,data)=>{
    // console.log("id", data )
    setPostUser(data);
    handleUpdateData()
    setId(id);
 
  }

  const handleUpdateData=()=>{
    axios.put(`http://localhost:3001/users/${id}`, PostUser)
    .then((response)=>{
      // console.log(response.data)
      getUserData();
    }).catch((error)=>{
        console.log(error)
    })

  }

//Delete the data from json
const deleteUserData=(id)=>{
  axios.delete(`http://localhost:3001/users/${id}`)
  .then((res)=>{
      console.log(res.data);
      getUserData();
  }).catch((error)=>console.warn(error));
}


    return (
      <div className="container mt-3" style={{ color: "rgb(41, 41, 106)" }}>
        <div className="row">

          <div className="col-lg-5 col-12 p-5 border border-3 ">
            <form>
              <div className="row ">
                <h1><i> Just few details</i></h1>
                <hr />
                <div className="col">
                  <label for=""><b>Full Name</b></label>
                  <input type="text" className="form-control" value={PostUser.fname} placeholder="First name" onChange={(e) => formStateChange(e, "FNAME")} />
                </div>
                <div className="col">
                  <label for=""><b>Last Name</b></label>
                  <input type="text" className="form-control" value={PostUser.lname}  placeholder="Last name" onChange={(e) => formStateChange(e, "LNAME")} />
                </div>
              </div>
              <div className="row mt-3">
                <div className="col">
                  <label for=""><b>Email</b></label>
                  <input type="email" className="form-control" value={PostUser.email} placeholder="Email" onChange={(e) => formStateChange(e, "EMAIL")} />
                </div>
              </div>
              <div className="row mt-3">
                <div className="col">
                  <label for=""><b>Mobile No</b></label>
                  <input type="Number" className="form-control" value={PostUser.mobile} placeholder="Mobile No" onChange={(e) => formStateChange(e, "MOBILE")} />
                </div>
              </div>
              <div className="row mt-3">
                <div className="col">
                  <label for=""><b>Address</b></label>
                  <input type="text" className="form-control" value={PostUser.address} placeholder="Address" onChange={(e) => formStateChange(e, "ADDRESS")} />
                </div>
              </div>
              <div className="row mt-4">
                <div className="col">
                  <button type="submit" className="btn text-white fw-bold me-3 px-4" onClick={()=>{postUserData()}}>SUBMIT</button>
                  <button type="submit" className="btn text-white fw-bold px-4" onClick={()=>{handleUpdateData()}}>Update</button>
                </div>
              </div>
            </form>
          </div>
          <div className="col-lg-7 col-12 border border-3 ">
            <table className="table table-striped custab mt-5">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Mobile</th>
                  <th className="text-center">Action</th>
                </tr>
              </thead>
              {
                UserData.map((value, index) => {
                  return (
                    <>
                     <tr className='border border-bottom'>
                      <td>{index + 1}</td>
                      <td>{value.fname} {value.lname}</td>
                      <td>{value.email}</td>
                      <td>{value.address}</td>
                      <td>{value.mobile}</td>
                      <td className="text-center">
                        <button className='btn btn-info btn-xs text-dark' onClick={()=>{editUserData(value.id, value)}}>
                          <span className="glyphicon glyphicon-edit" ></span> Edit</button>
                        <button className="btn btn-danger btn-xs text-dark" onClick={()=>{deleteUserData(value.id)}}>
                          <span className="glyphicon glyphicon-remove"></span> Del</button></td>
                    </tr >
                    
                    </>
                   
                  )
                })}

            </table>
          </div>
        </div>
      </div>

    )
  }

  export default Crud